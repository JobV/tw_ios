/**
 * Copyright (c) 2012-2014 Magnet Systems, Inc. All rights reserved.
 */

@interface NSButton (MMAdditions)

@property (assign, nonatomic, getter = isEnabled, setter = setEnabled:) BOOL enabled;

@end